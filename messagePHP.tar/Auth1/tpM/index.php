<!doctype html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Bonjour depuis PHP </title>
        <link rel="stylesheet" href="../StpM/index.css">
    </head>
    <body>
        <div class="div1">
            <h1> Bienvenus dans Chat One !</h1>
            <div class="sdiv1">
                <a href="cCompte.php">Créer un compte</a>
            </div>

            <div class="sdiv2">
                <a href="sCompte.php">Se connecter à mon compte</a>
            </div>
        </div>
    </body>
</html>
