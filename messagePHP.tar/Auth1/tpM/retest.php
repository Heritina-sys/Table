<?php
    session_start();
    echo "Votre nom n'existe pas <br>";
    echo "<br>";
    include("sCompte.php");
?>
