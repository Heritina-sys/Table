<?php
        class Bdd {
                private $bdd;
                //Connection a la base de donnée mit et affecter cette base dans $bdd//
                public function __construct() {
                        try{
                                $this->bdd = new PDO('mysql:host=localhost;dbname=Ma_base', 'phpmyadmin', 'p');
 //                             echo 'Connection etablis !!';
                                }
                        catch(PDOExeption $pe){
                                echo 'ERREUR : '.$pe->getMessage();
                        }
                }
		public function addPersonne($nom,$mail,$password){
                        $com = 'INSERT INTO Personne(nom_personne,mail_personne,mot_de_passe,creation_personne) VALUES(:nom_personne,:mail_personne,:mot_de_passe,NOW())';
                        $req = $this->bdd->prepare($com);
                        $req->execute(array(
                                'nom_personne' => $nom,
				'mail_personne' => $mail,
				'mot_de_passe' => $password,
                        ));
		}
		public function authentification($nom,$password){
			$reponse = $this->bdd->query('SELECT * FROM Personne');
			    ///testons si le nom existe ou pas
			while($donnees = $reponse->fetch()){
				if($nom == $donnees['nom_personne'] && $password == $donnees['mot_de_passe']){
					return true;
				}
			}
			return false;
		}
                public function verifycompte($nom,$mail){
                        $reponse = $this->bdd->query('SELECT * FROM Personne');
                            ///testons si le nom existe ou pas
                        while($donnees = $reponse->fetch()){  
                                if($nom == $donnees['nom_personne'] && $mail == $donnees['mail_personne']){
                                        return true;
                                }
                        }
                        return false;
                }
		public function envoyemessage($source,$destination,$message){
                        $com = 'INSERT INTO Message(source,destination,message,date_message) VALUES(:source,:destination,:message,NOW())';
                        $req = $this->bdd->prepare($com);
                        $req->execute(array(
                                'source' => $source,
                                'destination' => $destination,
                                'message' => $message,
                        ));
		}
		public function addContacte($perso1,$perso2){
                        $com = 'INSERT INTO Contacte(source,destination) VALUES(:source,:destination)';
                        $req = $this->bdd->prepare($com);
                        $req->execute(array(
                                'source' => $perso1,
                                'destination' => $perso2,
                        ));
		}
		public function contacte($perso1){
 			   $requete = $this->bdd->prepare("SELECT * FROM Contacte WHERE source = :source");
 			   $requete->execute(array(':source' => $perso1));
 			   $resultats = $requete->fetchAll(PDO::FETCH_ASSOC);
 			   return $resultats;
		}
		public function mp($source,$destination){
		    $requete = $this->bdd->prepare("SELECT * FROM Message WHERE source = :source AND destination = :destination OR source = :s2 AND destination = :d2");
		    $requete->execute(array(':source' => $source, ':destination' => $destination , 's2' => $destination, 'd2' => $source));
		    $resultats = $requete->fetchAll(PDO::FETCH_ASSOC);
		    return $resultats;
		}
                public function __destruct(){

               }
	}
?>
