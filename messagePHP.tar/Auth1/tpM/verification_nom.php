<?php
    echo "Le nom existe déja";
    include("cCompte.php");
?>
