import personne.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class myservelets
 */
public class myservelets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public myservelets() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at 3: ").append(request.getContextPath());
		System.out.println("Ok");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		Personne p1 = new Personne();
		String nom = null;
		String mail;
		String password;
		String source = request.getParameter("source");
		boolean log;
		request.setAttribute("p1",p1);
		if(source != null && source.equals("index")) {
			nom = request.getParameter("nom");
			mail = request.getParameter("mail");
			password = request.getParameter("password");
			boolean value = p1.verificompte(nom, mail);
			if(!value) {
			p1.addPersonne(nom,mail,password);
			request.setAttribute("nom",nom);
			request.getRequestDispatcher("message.jsp").forward(request, response);
			}
			else {
				response.sendRedirect("index.html");
			}
		}
		else if(source != null && source.equals("connecter")) {
			nom = request.getParameter("nom");
			password = request.getParameter("password");
			log = p1.authentification(nom, password);
			if(log) {
				request.setAttribute("nom",nom);
				request.getRequestDispatcher("message.jsp").forward(request, response);	
			}
			else if(!log) {
				response.sendRedirect("connecter.html");
			}
		}
		else if(source !=null && source.equals("message")) {
			String message = request.getParameter("message");
			String sourceP = request.getParameter("sourceP");
			String destination = request.getParameter("destination");
			p1.addContacte(destination, sourceP);
			p1.addContacte(sourceP,destination);
			p1.envoyeMessage(sourceP, destination, message);
			request.setAttribute("nom",sourceP);
			request.getRequestDispatcher("message.jsp").forward(request, response);	
		}
		System.out.println("Fais.");
	}
}
