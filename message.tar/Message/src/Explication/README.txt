Ceci est une projet d'envoye de Message
Les utilisateurs peuvent parler et discuter librement en priver
Ceci est encore la verison BETA donc pas encore très optimale
Ceci est Open-source
Pour l'utiliser :
	-Importer le fichier message.sql dans mysql ou mariadb
	-Verifier votre connexion a la base dans le fichier Personne.java du package personne
Puis lancer index.html
C'est tout!!!
	