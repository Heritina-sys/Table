-- Création de la base de données Message
CREATE DATABASE IF NOT EXISTS Message;

-- Utilisation de la base de données Message
USE Message;

-- Création de la table Chat
CREATE TABLE IF NOT EXISTS Chat (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Nom VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    date_creation DATE NOT NULL
);

-- Création de la table Compte
CREATE TABLE IF NOT EXISTS Compte (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Nom VARCHAR(255) NOT NULL,
    Password TEXT NOT NULL,
    date_creation DATE NOT NULL
);
