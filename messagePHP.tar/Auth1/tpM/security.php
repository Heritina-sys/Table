<?php
    session_start();
    echo "Invalidation du mot de passe";
    include ("sCompte.php");
?>
