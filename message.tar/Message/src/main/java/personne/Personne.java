package personne;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.cj.xdevapi.Statement;

public class Personne {		//Class Personne qui est au niveau de gestion du base de donnés : 
	private static final String URL = "jdbc:mysql://localhost/Ma_base";
    private static final String UTILISATEUR = "phpmyadmin";
    private static final String MOT_DE_PASSE = "p";
    Connection connexion;
	public Personne() {
	    try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            connexion = DriverManager.getConnection(URL, UTILISATEUR, MOT_DE_PASSE);
            System.out.println("Connexion à la base de données réussie !");
//            connexion.close();
        } catch (ClassNotFoundException e) {
            System.err.println("Erreur de chargement du driver JDBC : " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Erreur de connexion à la base de données : " + e.getMessage());
        }
	}
    public void addPersonne(String nom, String mail, String password) {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String date1 = formatter.format(date);
        String requete = "INSERT INTO Personne (nom_personne,mail_personne,mot_de_passe,creation_personne) VALUES (?,?,?,?)";
        PreparedStatement statement = null;
        try {
            statement = connexion.prepareStatement(requete);
            statement.setString(1, nom);
            statement.setString(2, mail);
            statement.setString(3, password);
            statement.setString(4, date1);
            statement.executeUpdate();
            System.out.println("Ajout fais");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
        	try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }
    public boolean authentification(String nom,String password) {
    	  String requete = "SELECT COUNT(*) FROM Personne WHERE nom_personne = ? AND mot_de_passe = ?";
          PreparedStatement statement = null;
		try {
			statement = connexion.prepareStatement(requete);
	        statement.setString(1, nom);
	        statement.setString(2, password);
	        ResultSet resultat = statement.executeQuery();
	          if (resultat.next()) {
	              int count = resultat.getInt(1);
	              return count > 0;
	          }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        finally {
        	try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
          return false;
    }
    public boolean verificompte(String nom,String mail) {
    	String sql = "SELECT COUNT(*) FROM Personne WHERE nom_personne = ? OR mail_personne = ?";
        PreparedStatement statement = null; 
    	try {
       		statement = connexion.prepareStatement(sql);
               statement.setString(1, nom);
               statement.setString(2, mail);
               ResultSet resultSet = statement.executeQuery();
               resultSet.next();
               int count = resultSet.getInt(1);
               if (count > 0) {
            	   return true;
               } else {
            	   return false;
               }

           } catch (SQLException e) {
               e.printStackTrace();
           }
    	return false;
    }
    public void closeConnexion() {
    	try {
			connexion.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    public void envoyeMessage(String source,String destination,String message) {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String date1 = formatter.format(date);        
        String requete = "INSERT INTO Message (source,destination,message,date_message) VALUES (?,?,?,?)";
        PreparedStatement statement = null;
        try {
            statement = connexion.prepareStatement(requete);
            statement.setString(1, source);
            statement.setString(2, destination);
            statement.setString(3, message);
            statement.setString(4, date1);
            statement.executeUpdate();
            System.out.println("Message fais");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
        	try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }
    public void addContacte(String perso1,String perso2) {        
         String requete = "INSERT INTO Contacte (source,destination) VALUES (?,?)";
         PreparedStatement statement = null;
         try {
             statement = connexion.prepareStatement(requete);
             statement.setString(1, perso1);
             statement.setString(2, perso2);
             statement.executeUpdate();
             System.out.println("Contacte fais");
         } catch (SQLException e) {
             e.printStackTrace();
         }
         finally {
         	try {
 				statement.close();
 			} catch (SQLException e) {
 				// TODO Auto-generated catch block
 				e.printStackTrace();
 			}
         }
    }
public ArrayList<String> contacte(String source) {
		ArrayList<String> tab = new ArrayList<>();
        String chaine = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "SELECT destination FROM Contacte WHERE source=?";
        try {
        	stmt = connexion.prepareStatement(sql);
        	stmt.setString(1, source);
        	rs = stmt.executeQuery();
        	while (rs.next()) {
        		chaine = rs.getString("destination");
        		tab.add(chaine);
        	}
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return tab;
}
public ArrayList<ArrayList<String>> mp(String source,String destination) {
	ArrayList<ArrayList<String>> tab = new ArrayList<>();
    String chaine = null;
    String chaine2 = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    String sql = "SELECT message,date_message FROM Message WHERE source=? AND destination=? OR source=? AND destination=?";
    try {
    	stmt = connexion.prepareStatement(sql);
    	stmt.setString(1, source);
    	stmt.setString(2, destination);
    	stmt.setString(3, destination);
    	stmt.setString(4, source);
    	
    	rs = stmt.executeQuery();
    	while (rs.next()) {
    		ArrayList<String> tab2 = new ArrayList<>();
    		chaine = rs.getString("message");
    		chaine2 = rs.getString("date_message");
    		tab2.add(chaine);
    		tab2.add(chaine2);
    		tab.add(tab2);
    	}
    }catch (SQLException e) {
        e.printStackTrace();
    }
    return tab;
	}
}

